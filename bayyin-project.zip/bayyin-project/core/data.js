const usersData = [
    {
        id: 1,
        email: 'admin1@gmail.com',
        username: 'admin 1',
        password: 'admin123',
        role: 'pemilik',
    },
    {
        id: 2,
        email: 'workera@gmail.com',
        username: 'worker A',
        password: 'workera123',
        role: 'pekerja',
    },
    {
        id: 3,
        email: 'workerb@gmail.com',
        username: 'worker b',
        password: 'workerb123',
        role: 'pekerja',
    },
    {
        id: 4,
        email: 'rudi@gmail.com',
        username: 'rudi',
        password: '12345678',
        role: 'pengguna',
    },
    {
        id: 5,
        email: 'dian@gmail.com',
        username: 'dian',
        password: '12345678',
        role: 'pengguna',
    },
]